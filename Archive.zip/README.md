# learnings
what i'm currently learning in programming. practiced and tracked here.
